import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
export class OnlineWalletBean{
  constructor(
    public customerId:number,
    public customerName:string,
    public accountBalance:number,
    public customerPassword:string)
   {}
}
export class TransferBean{
  constructor(
  public customerId1:number,
  public customerId2:number,
  
  public amount:number)
{}

}
export class ShowBalanceBean{
  constructor(
  public customerId:number)

{}
  }
  export class AddAmountBean{
    constructor(
    public customerId:number,
    public addamount:number)
  
  {}
    }

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  onlinewalletBean:OnlineWalletBean[];
  transferBean:TransferBean[];
  showBalancebean:ShowBalanceBean[];
  addAmountBean:AddAmountBean[];
  constructor(private httpClient:HttpClient) { }

 getWallet(){
  console.log("test call");
  return this.httpClient.get<OnlineWalletBean[]>('http://localhost:8093/onlinewallet/getAll');
}

public deleteWallet(onlinewalletBean) {
  return this.httpClient.delete<OnlineWalletBean>("http://localhost:8093/onlinewallet/delete/"+onlinewalletBean.customerId);
}

public createWallet(onlinewalletBean):Observable<OnlineWalletBean>
{
  console.log(onlinewalletBean);
return this.httpClient.post<OnlineWalletBean>("http://localhost:8093/onlinewallet/create", onlinewalletBean,{responseType:'json'});
}

public updateWallet(onlinewalletBean) {
  console.log(onlinewalletBean);
  return this.httpClient.put<OnlineWalletBean>("http://localhost:8093/onlinewallet/update", onlinewalletBean);
}

public showBalance(showBalancebean) {
  return this.httpClient.get<ShowBalanceBean>("http://localhost:8093/onlinewallet/showBalance/"+showBalancebean.customerId);
}
public deposit(transferBean) {
  console.log(transferBean);
  return this.httpClient.post<TransferBean>("http://localhost:8093/onlinewallet/fundtransfer", transferBean);
}
public addAmount(addAmountBean){
  return this.httpClient.get<AddAmountBean>("http://localhost:8093/onlinewallet/addAmount/"+addAmountBean.customerId+"/"+addAmountBean.addamount);

}
}
