import { Component, OnInit } from '@angular/core';
import { ServiceService, OnlineWalletBean,ShowBalanceBean } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-wallet',
  templateUrl: './show-wallet.component.html',
  styleUrls: ['./show-wallet.component.css']
})
export class ShowWalletComponent implements OnInit {
  showBalanceBean:ShowBalanceBean[];
  user: ShowBalanceBean = new ShowBalanceBean(0);
  constructor(private service: ServiceService,private router: Router) { }
  balance:any;

  ngOnInit(): void{
  }
  showBalance() :void{
    console.log(this.user);

    this.service.showBalance(this.user).subscribe( data =>
       {
         console.log(data);
         this.balance=data;
          alert("Hi Customer your account balance is "+this.balance.accountBalance); });
}
}