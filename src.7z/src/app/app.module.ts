import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateWalletComponent } from './create-wallet/create-wallet.component';
import { HttpClient,HttpClientModule } from '@angular/common/http';
import { ServiceService } from './service.service';
import { ReactiveFormsModule } from '@angular/forms';


import { ShowWalletComponent } from './show-wallet/show-wallet.component';
import { UpdateWalletComponent } from './update-wallet/update-wallet.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';

import { TransferComponent } from './transfer/transfer.component';
import { AddAmountComponent } from './add-amount/add-amount.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateWalletComponent,
    
    ShowWalletComponent,
    
    UpdateWalletComponent,
    
    FooterComponent,
    
    HeaderComponent,
    

    TransferComponent,
    
    AddAmountComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [HttpClient,ServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
