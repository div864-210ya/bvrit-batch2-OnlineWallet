import { Component, OnInit } from '@angular/core';
import { ServiceService,AddAmountBean } from '../service.service';
import { Router} from '@angular/router';
@Component({
  selector: 'app-add-amount',
  templateUrl: './add-amount.component.html',
  styleUrls: ['./add-amount.component.css']
})
export class AddAmountComponent implements OnInit {
  addAmountBean:AddAmountBean[];
  user: AddAmountBean = new AddAmountBean(0,0);
  
  constructor(private service: ServiceService,private router: Router) { }

  ngOnInit(): void{
  }
  addAmount() :void{
    this.service.addAmount(this.user).subscribe( data => { alert("Amount added successfully"); });
}
}