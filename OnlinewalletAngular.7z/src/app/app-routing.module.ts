import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateWalletComponent } from './create-wallet/create-wallet.component';
import { ShowWalletComponent } from './show-wallet/show-wallet.component';
import { UpdateWalletComponent } from './update-wallet/update-wallet.component';
import { TransferComponent } from './transfer/transfer.component';
import { AddAmountComponent } from './add-amount/add-amount.component';


const routes: Routes = [
  { path:'app-show-wallet', component:ShowWalletComponent },
  { path:'app-create-wallet', component:CreateWalletComponent }, 
   {path:'app-update-wallet', component:UpdateWalletComponent },
   {path:'app-transfer', component:TransferComponent},
   {path:'app-add-amount',component:AddAmountComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
