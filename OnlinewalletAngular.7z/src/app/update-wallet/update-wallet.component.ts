import { Component, OnInit } from '@angular/core';
import { ServiceService,OnlineWalletBean } from '../service.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-update-wallet',
  templateUrl: './update-wallet.component.html',
  styleUrls: ['./update-wallet.component.css']
})
export class UpdateWalletComponent implements OnInit {
  user: OnlineWalletBean = new OnlineWalletBean(0,"",0,"");
    constructor(private service: ServiceService) { }

  ngOnInit() {
  }
    updateWallet(): void {
      console.log(this.user.customerId);
      this.service.updateWallet(this.user)
          .subscribe( data => {
            alert("Wallet updated successfully.");
          });

        };
      }
      