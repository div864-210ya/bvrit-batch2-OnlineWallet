import { Component, OnInit } from '@angular/core';
import { ServiceService,TransferBean } from '../service.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {
  user: TransferBean = new TransferBean(0,0,0);

  constructor(private service: ServiceService,private router: Router) { }
   /**
 * leftoutamount:any;
 */
  ngOnInit(): void{
  }
  deposit() :void{
    console.log(this.user);
    this.service.deposit(this.user).subscribe( data =>
       {
         /** 
         console.log(data);
         this.leftoutamount=data;
         */
          alert("Successfully tansfered the amount of Rs 100") });
}
}