import { Component, OnInit } from '@angular/core';
import { ServiceService,OnlineWalletBean } from '../service.service';
import { Router} from '@angular/router';


@Component({
  selector: 'app-create-wallet',
  templateUrl: './create-wallet.component.html',
  styleUrls: ['./create-wallet.component.css']
})
export class CreateWalletComponent implements OnInit {
  user: OnlineWalletBean = new OnlineWalletBean(0,"",0,"");

  constructor(private service: ServiceService,private router: Router) { }
wallet:any;
  ngOnInit(): void{
  }
  createWallet() :void{
    console.log(this.user);
    this.service.createWallet(this.user).subscribe( data =>
       {
         console.log(data);
         this.wallet=data;
          alert("Wallet created successfully and your account ID is"+this.wallet.customerId); });
}
}